object Coil {
    // https://coil-kt.github.io/coil/compose/
    private const val version = "1.3.0"
    const val coil = "io.coil-kt:coil-compose:$version"
}