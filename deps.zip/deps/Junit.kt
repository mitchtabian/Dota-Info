object Junit {
    private const val version = "4.12"
    const val junit4 = "junit:junit:4.12"
}