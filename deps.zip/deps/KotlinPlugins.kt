object KotlinPlugins {
    const val serialization = "plugin.serialization"
}