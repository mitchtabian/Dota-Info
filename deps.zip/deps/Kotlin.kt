object Kotlin {
    const val version = "1.5.10"
}